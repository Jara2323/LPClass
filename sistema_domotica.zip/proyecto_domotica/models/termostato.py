from models.dispositivo_base import DispositivoBase

class Termostato(DispositivoBase):

    def __init__(self, id_termo: int, nombre: str, temperatura: float, objetivo: float, agente: int):
        super().__init__(id_termo, nombre, agente)
        self._temperatura = temperatura
        self._objetivo = objetivo
        self._activo = True

    @property
    def temperatura(self) -> float:
        return self._temperatura

    @temperatura.setter
    def temperatura(self, valor: float):
        self._temperatura = valor

    @property
    def objetivo(self) -> float:
        return self._objetivo

    @objetivo.setter
    def objetivo(self, valor: float):
        self._objetivo = valor

    def encender(self):
        self._activo = True

    def apagar(self):
        self._activo = False

    def ajustar_objetivo(self, nueva_temp: float):
        self._objetivo = nueva_temp

    def necesita_calefaccion(self) -> bool:
        return self._temperatura < self._objetivo

    def necesita_enfriamiento(self) -> bool:
        return self._temperatura > self._objetivo

    def obtener_estado(self) -> str:
        diferencia = self._objetivo - self._temperatura
        if diferencia > 0:
            accion = f"Calentando (+{diferencia:.1f}C)"
        elif diferencia < 0:
            accion = f"Enfriando ({diferencia:.1f}C)"
        else:
            accion = "Temperatura optima"

        return f"{self.obtener_info_basica()} - Actual: {self._temperatura}C | Objetivo: {self._objetivo}C | {accion}"

    def obtener_info(self) -> dict:
        info = super().obtener_info()
        info['temperatura'] = self._temperatura
        info['objetivo'] = self._objetivo
        info['tipo'] = 'Termostato'
        return info

    def __str__(self):
        return self.obtener_estado()
