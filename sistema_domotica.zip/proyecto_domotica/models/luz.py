from models.dispositivo_base import DispositivoBase

class Luz(DispositivoBase):

    def __init__(self, id_luz: int, nombre: str, encendida: bool, agente: int):
        super().__init__(id_luz, nombre, agente)
        self._encendida = encendida
        self._activo = True

    @property
    def encendida(self) -> bool:
        return self._encendida

    def encender(self):
        self._encendida = True
        self._activo = True

    def apagar(self):
        self._encendida = False
        self._activo = False

    def alternar(self):
        if self._encendida:
            self.apagar()
        else:
            self.encender()

    def obtener_estado(self) -> str:
        estado = "Encendida" if self._encendida else "Apagada"
        return f"{self.obtener_info_basica()} - {estado}"

    def obtener_info(self) -> dict:
        info = super().obtener_info()
        info['encendida'] = self._encendida
        info['tipo'] = 'Luz'
        return info

    def __str__(self):
        return self.obtener_estado()
