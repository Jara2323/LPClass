from .dispositivo_base import DispositivoBase
from .luz import Luz
from .termostato import Termostato
from .contenedor_residuos import ContenedorResiduos
from .bateria import Bateria

__all__ = ['DispositivoBase', 'Luz', 'Termostato', 'ContenedorResiduos', 'Bateria']
