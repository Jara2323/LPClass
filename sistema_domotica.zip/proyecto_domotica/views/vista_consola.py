class VistaConsola:

    @staticmethod
    def mostrar_menu_principal():
        print("\n" + "="*50)
        print(" SISTEMA DE AUTOMATIZACION DEL HOGAR ".center(50))
        print("="*50)
        print("\n1. Gestionar Luces")
        print("2. Gestionar Termostatos")
        print("3. Gestionar Contenedores de Residuos")
        print("4. Ver Estado de Baterias")
        print("5. Ver Todo el Sistema")
        print("6. Ver Dispositivos por Agente")
        print("0. Salir")
        print("-"*50)

    @staticmethod
    def mostrar_menu_luces():
        print("\n--- GESTION DE LUCES ---")
        print("1. Ver todas las luces")
        print("2. Encender luz")
        print("3. Apagar luz")
        print("4. Alternar luz")
        print("0. Volver")

    @staticmethod
    def mostrar_menu_termostatos():
        print("\n--- GESTION DE TERMOSTATOS ---")
        print("1. Ver todos los termostatos")
        print("2. Ajustar temperatura objetivo")
        print("3. Simular cambio de temperatura")
        print("0. Volver")

    @staticmethod
    def mostrar_menu_contenedores():
        print("\n--- GESTION DE CONTENEDORES ---")
        print("1. Ver todos los contenedores")
        print("2. Vaciar contenedor")
        print("3. Actualizar nivel")
        print("4. Ver contenedores llenos")
        print("0. Volver")

    @staticmethod
    def mostrar_menu_baterias():
        print("\n--- ESTADO DE BATERIAS ---")
        print("1. Ver todas las baterias")
        print("2. Cargar bateria")
        print("3. Consumir energia")
        print("0. Volver")

    @staticmethod
    def mostrar_lista(titulo: str, items: list):
        print(f"\n{titulo}")
        print("-" * 70)
        if not items:
            print("  No hay elementos para mostrar")
        else:
            for item in items:
                print(f"  {item}")
        print("-" * 70)

    @staticmethod
    def mostrar_mensaje(mensaje: str, tipo: str = "info"):
        iconos = {
            "exito": "[OK]",
            "error": "[ERROR]",
            "info": "[INFO]",
            "alerta": "[ALERTA]"
        }
        icono = iconos.get(tipo, "")
        print(f"\n{icono} {mensaje}")

    @staticmethod
    def solicitar_entrada(mensaje: str) -> str:
        return input(f"\n{mensaje}: ")

    @staticmethod
    def mostrar_estado_sistema(luces, termostatos, contenedores, baterias):
        print("\n" + "="*70)
        print(" ESTADO COMPLETO DEL SISTEMA ".center(70))
        print("="*70)

        VistaConsola.mostrar_lista("LUCES", luces)
        VistaConsola.mostrar_lista("TERMOSTATOS", termostatos)
        VistaConsola.mostrar_lista("CONTENEDORES DE RESIDUOS", contenedores)
        VistaConsola.mostrar_lista("BATERIAS", baterias)
