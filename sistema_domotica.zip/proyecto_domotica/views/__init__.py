from .vista_consola import VistaConsola

__all__ = ['VistaConsola']
