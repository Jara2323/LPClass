from .dispositivo_interface import IDispositivo

__all__ = ['IDispositivo']
